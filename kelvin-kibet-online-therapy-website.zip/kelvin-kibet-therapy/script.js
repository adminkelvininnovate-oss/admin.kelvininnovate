document.querySelector(".menu-toggle").addEventListener("click", () => {
  const nav = document.querySelector("nav");
  nav.style.display = nav.style.display === "flex" ? "" : "flex";
  nav.style.position = "absolute";
  nav.style.top = "76px";
  nav.style.left = "0";
  nav.style.right = "0";
  nav.style.padding = "18px 5%";
  nav.style.background = "#fff";
  nav.style.flexDirection = "column";
  nav.style.borderBottom = "1px solid #e9efec";
});

document.querySelectorAll("nav a").forEach(a => a.addEventListener("click", () => {
  if (window.innerWidth <= 900) document.querySelector("nav").style.display = "";
}));

document.getElementById("booking-form").addEventListener("submit", e => {
  e.preventDefault();
  const data = new FormData(e.target);
  const subject = encodeURIComponent("Online Counselling Session Request");
  const body = encodeURIComponent(
    `Name: ${data.get("name")}\nEmail: ${data.get("email")}\n\nMessage:\n${data.get("message") || ""}`
  );
  window.location.href = `mailto:admin.kelvininnovate@gmail.com?subject=${subject}&body=${body}`;
});
