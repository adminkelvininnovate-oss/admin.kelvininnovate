# Kelvin Kibet — Counselling Psychology Website

A responsive static website for Kelvin Kibet, Counsellor & Online Therapist.

## Run locally
Open `index.html` in a browser.

## Deploy to Vercel
1. Create a GitHub repository and upload `index.html`, `style.css`, and `script.js`.
2. Sign in to Vercel and choose **Add New Project**.
3. Import the GitHub repository.
4. For this static site, leave the framework preset as **Other** and deploy.
5. Vercel will provide a `*.vercel.app` address.

## Before publishing
Replace the photo placeholders with Kelvin's professional photos. Also confirm the professional title/registration wording you want to use publicly.
